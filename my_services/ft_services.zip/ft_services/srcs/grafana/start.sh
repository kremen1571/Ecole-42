#!bin/sh

#cd grafana-7.3.4
#./bin/grafana-server web
/usr/sbin/grafana-server --homepath=/usr/share/grafana