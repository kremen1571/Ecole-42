#!bin/sh

influxd -config /etc/conf.d/influxdb.conf